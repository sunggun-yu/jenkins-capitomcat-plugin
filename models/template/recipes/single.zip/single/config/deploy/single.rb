# Application host section for Single Stage
## Empty configuration should be fine.
